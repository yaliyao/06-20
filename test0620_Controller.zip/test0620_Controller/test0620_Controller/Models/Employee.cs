﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace test0620_Controller.Models {
    public class Employee {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}